package cpsc2150.extendedTicTacToe;
import java.util.*;

public class GameBoardMem extends AbsGameBoard {
    /**
     *@invariant MAX_marks < MAX_row
     *@invariant MAX_marks < MAX_col
     */
    private Map<Character, List<BoardPosition>> board = new HashMap< Character, List<BoardPosition> >();
    private final int MAX_row;
    private final int MAX_col;
    private final int MAX_marks;
    /**
     *@param MAX-row is the maximum number of rows
     *@param MAX-col is the maximum number of columns
     *@param MAX-marks is the maximum number of markers in a row needed to win
     *@pre the MAX_row and MAX_col cannot exceed 99, MAX_marks cannot exceed 25, and all three inputs must be greater than 2
     *@post The three parameters are stored
     */
    public GameBoardMem(int MAX_row, int MAX_col, int MAX_marks) {
        this.MAX_row = MAX_row-1;
        this.MAX_col = MAX_col-1;
        this.MAX_marks = MAX_marks;
    }
    @Override
    public boolean isPlayerAtPos(BoardPosition lastPos, char player) {
        List<BoardPosition> choicesList = board.get(player);

        if(choicesList.contains(lastPos))
            return true;

        return false;
    }

    public char whatsAtPos(BoardPosition lastPos) {

        char containedCharacter = ' ';
        List<BoardPosition> choicesList;
        for(Map.Entry<Character, List<BoardPosition>> m: board.entrySet()){
            choicesList = m.getValue();

            if(m.getValue().contains(lastPos))
                containedCharacter = m.getKey();
        }
        //System.out.println("Row" + row + "Column" +   + "Character" + containedCharacter);
        return containedCharacter;
    }

    public void placeMarker(BoardPosition marker, char player) {

        if(!board.containsKey(player)) {
            List<BoardPosition> location = new ArrayList<>();
            location.add(marker);
            board.put(player, location);
        }
        else
            board.get(player).add(marker);
    }

    public int getNumRows() {
        return MAX_row;
    }

    public int getNumColumns() {
        return MAX_col;
    }

    public int getNumToWin() {
        return MAX_marks;
    }
}
