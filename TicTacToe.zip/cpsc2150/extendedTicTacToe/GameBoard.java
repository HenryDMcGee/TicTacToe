package cpsc2150.extendedTicTacToe;

public class GameBoard extends AbsGameBoard {
    /**
    *@invariant MAX_marks < MAX_row
    *@invariant MAX_marks < MAX_col
     *@correspondance MAX_row = boards number of rows (maximum number you can choose for a row)
     * @correspondance MAX_row = boards number of columns (maximum number you can choose for a column)
     * @correspondance MAX_marks = number of markers in a row
    */
    private char[][] board;
    private final int MAX_row;
    private final int MAX_col;
    private final int MAX_marks;
    /**
    *@param MAX-row is the maximum number of rows
    *@param MAX-col is the maximum number of columns
    *@param MAX-marks is the maximum number of markers in a row needed to win
    *@pre the MAX_row and MAX_col cannot exceed 100, MAX_marks cannot exceed 25, and all three inputs must be greater than 2
    *@post a gameboard of size 8x8 is created using an array.
    */
    public GameBoard(int MAX_row, int MAX_col, int MAX_marks) {
        int i = 0;
        int j = 0;

        this.MAX_row = MAX_row-1;
        this.MAX_col = MAX_col-1;
        this.MAX_marks = MAX_marks;

        board = new char[MAX_row+1][MAX_col+1];

        for(i = 0; i < MAX_row + 1; i++) {
            for(j = 0; j < MAX_col + 1; j++) {
                board[i][j] = ' ';
            }
        }
    }

    /**
    *@return char of the player name (X or O or ' ') located at the given cpsc2150.extendedTicTacToe.BoardPosition object. (row and column in object)
    *@param BoardPosition object of players last move including row and column.
    *@pre The cpsc2150.extendedTicTacToe.BoardPosition object contains a valid row and column within the grid and not already taken.
    *@post returns the char for given row and column, so ' ', 'X', or 'O'.
    */
    public char whatsAtPos(BoardPosition lastPos) {
        int row = lastPos.getRow();
        int col = lastPos.getColumn();
        char containedCharacter;

        containedCharacter = board[row][col];

        return containedCharacter;
    }

    /**
    *@param BoardPosition object of row and column to place.
    *@param char player to place (X or O) at given location.
    *@pre the cpsc2150.extendedTicTacToe.BoardPosition object is within bounds and not already taken.
    *Player name is valid X or O.
    *@post a marker of the players name is located at the given position.
    */
    public void placeMarker(BoardPosition marker, char player) {
        int row = marker.getRow();
        int col = marker.getColumn();

        if(board[row][col] == ' ') {
            board[row][col] = player;
        }
    }

    public int getNumRows() {
        return MAX_row;
    }

    public int getNumColumns() {
        return MAX_col;
    }

    public int getNumToWin() {
        return MAX_marks;
    }
}
