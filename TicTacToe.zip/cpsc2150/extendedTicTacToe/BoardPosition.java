package cpsc2150.extendedTicTacToe;


public class BoardPosition {

    /**
     * @invariant the row and column are permanent once the object is created.
     */
    private int Row;
    private int Column;

    public BoardPosition(int Row, int Column) {
        this.Row = Row;
        this.Column = Column;
    }

    /**
     * @param row    is the horizontal section of the board
     * @param column is the vertical section of the board
     * @pre (row and column) > 0 and <9. No repeating row and column combos.
     * @post cpsc2150.extendedTicTacToe.BoardPosition object will be constructed with values row and column.
     */



    /**
     * +@return the int value for row will be returned
     *
     * @pre client must be sure a valid variable is being compared with the returned int
     * @post an int value for row will be returned
     */
    public int getRow() {
        return Row;
    }

    /**
     * @return the int value for column will be returned
     * @pre client must be sure a valid variable is being compared with the returned int
     * @post an int value for column will be returned
     */
    public int getColumn() {
        return Column;
    }

    /**
     * @param obj, since every class extends from Object class, any class object to compare
     * @return boolean: returns a true if objects are of the same type, otherwise returns false
     * @pre use a valid obj to find out if it shares the same class with another
     * @post objects are compared based on class type
     */
    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof BoardPosition))
            return false;
        BoardPosition p = (BoardPosition) obj;
        if(this.Row == p.Row
            && this.Column == p.Column) {
            return true;
        }
        return false;
    }

    /**
     * @return a string of the object value.
     * @pre a valid object must be used.
     * @post the object will not be modifed, only a string of its object values will be returned.
     */
    @Override
    public String toString() {
        String output = String.valueOf(Row);
        output = output + " ";
        output = output + String.valueOf(Column);

        return output;
    }
}