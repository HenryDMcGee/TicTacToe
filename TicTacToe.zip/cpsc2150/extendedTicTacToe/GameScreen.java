package cpsc2150.extendedTicTacToe;
import java.util.Scanner;

public class GameScreen {
    public static void main(String [] args) {
        Scanner input = new Scanner(System.in);
        //negative since negative numbers are not allowed on the board
        int row = -1;
        int column = -1;
        IGameBoard board;
        BoardPosition position;

        Boolean isTheGameFinishedBool;

        final int MIN_row = 3;
        final int MIN_col = 3;
        final int MIN_marks = 3;

        //not final since they need to be reassigned in the loop
        int MAX_row;
        int MAX_col;
        int MAX_marks;

        int[] size;
        //for fast or slow game
        String fastOrSlow = "";

        char[] player;
        int depth = 0;
        //choose number of players
        depth = setDepth();
        //set number of players
        player = new char[depth];
        //choose the player markers
        player = choosePlayerMarkers(depth, player);
        //Enter the character to represent player (number)
        //(char) is already taken as a player token!
        size = chooseBoardSizeAndMarkerNum();
        MAX_row = size[0];
        MAX_col = size[1];
        MAX_marks = size[2];

        //do while allows for code to at least run once
        //this loop allows for the game to be won
        //do while is not necessary, but is nice since it allows for variables to be assigned in the loop before
        //being used, otherwise while loop parameters have to be setup before the loop starts


        //Fast or slow
        do {
            System.out.println("Would you like a Fast Game (F/f) or a Memory Efficient Game (M/m?");
            fastOrSlow = input.nextLine();
            if(!fastOrSlow.equals("F") && !fastOrSlow.equals("f") && !fastOrSlow.equals("M") && !fastOrSlow.equals("m"))
                System.out.println("Please enter F or M");

        } while(!fastOrSlow.equals("F") && !fastOrSlow.equals("f") && !fastOrSlow.equals("M") && !fastOrSlow.equals("m"));

        if(fastOrSlow.equals("M") || fastOrSlow.equals("m"))
            board = new GameBoardMem(MAX_row, MAX_col, MAX_marks);
        else
            board = new GameBoard(MAX_row, MAX_col, MAX_marks);
        fastOrSlow = "";
        printBoard(board);
        int i = 0; // i increments
        int playerTurn = 0; //player turn uses the modulus operator of i and depth to get the player number in the player array who's turn it is
        do {
            playerTurn = i % depth;
            i++;
            //loop getting row and column until game is done
            //goes once, but continues to repeat if row and column are not valid, or location is already taken on the board
            do{
                //reassign row and column to out of bounds numbers, that way an error is thrown if they are not assigned values by the scanner object
                row = -1;
                column = -1;
                System.out.println("Player " + player[playerTurn] + " please enter your ROW");
                //check if user input is usable as an int, if not an int row is never assigned a new value
                //thus since row is assigned -1 before the loop it will continue to cycle
                if (input.hasNextInt())
                    row = input.nextInt();


                System.out.println("Player " + player[playerTurn] + " please enter your COLUMN");
                //check if usable as an int
                if (input.hasNextInt())
                    column = input.nextInt();

                position = new BoardPosition(row, column);

                if(((row < 0) || (row > board.getNumRows())) || ((column < 0) || (column > board.getNumColumns())) || (!board.checkSpace(position))) {
                    printBoard(board);
                    System.out.println("That space is unavailable, please pick again");
                }

            }while((row < 0) || (row > board.getNumRows()) || (column < 0) || (column > board.getNumColumns()) || (!board.checkSpace(position)));

            board.placeMarker(position, player[playerTurn]);
            printBoard(board);
            //this variables is used to avoid repeating the Y/N for finishing the game,
            //since both the current player and repeating of loop are determined by the
            //isTheGameFinished function
            isTheGameFinishedBool = isTheGameFinished(player[playerTurn], board, position);

            if(isTheGameFinishedBool) {
                depth = setDepth();
                player = new char[depth];
                player = choosePlayerMarkers(depth, player);
                size = chooseBoardSizeAndMarkerNum();
                MAX_row = size[0];
                MAX_col = size[1];
                MAX_marks = size[2];
                //Fast or slow
                do {
                    input.nextLine();
                    System.out.println("Would you like a Fast Game (F/f) or a Memory Efficient Game (M/m?");
                    fastOrSlow = input.nextLine();
                    if(!fastOrSlow.equals("F") && !fastOrSlow.equals("f") && !fastOrSlow.equals("M") && !fastOrSlow.equals("m"))
                        System.out.println("Please enter F or M");

                } while(!fastOrSlow.equals("F") && !fastOrSlow.equals("f") && !fastOrSlow.equals("M") && !fastOrSlow.equals("m"));

                if(fastOrSlow.equals("M") || fastOrSlow.equals("m"))
                    board = new GameBoardMem(MAX_row, MAX_col, MAX_marks);

                else
                    board = new GameBoard(MAX_row, MAX_col, MAX_marks);
                fastOrSlow = "";
                printBoard(board);
                isTheGameFinishedBool = false;
            }

        }while(!isTheGameFinishedBool);

        return;
    }
     /**
     * @return a false if the game is not finished. true if they player wishes to restart with a new board.
     *@param a char for which players turn it is, the current gameboard, and latest position on the board.
     *@pre The cpsc2150.extendedTicTacToe.GameBoard class has constructed an object, or board to check.
     *@post Prints if a win or draw occurred.
     *then asks player if they wish to continue and returns true if they say yes. If they say no ends the program
     *if a win or draw did not occur, returns false.
     */
    private static boolean isTheGameFinished(char player, IGameBoard board, BoardPosition position) {
        Scanner input = new Scanner(System.in);
        String response = "Q";

        if(board.checkForWinner(position)) {
            System.out.println("Player " + player + " wins!");
            printBoard(board);
            //loop until correct input
            while(((!response.equals("Y")) && (!response.equals("y"))) && ((!response.equals("N")) && (!response.equals("n")))) {
                //get Y or N to play again
                System.out.println("Would you like to play again? Y/N");
                response = input.nextLine();
                if ((response.equals("Y")) || (response.equals("y"))) {
                    //create new GameBoard, delete old one
                    return true;
                }
                if ((response.equals("N")) || (response.equals("n"))) {
                    System.exit(0);
                }
            }
        }

        if(board.checkForDraw()) {
            //print a draw has occured
            System.out.println("A draw has occurred!");
            printBoard(board);
            //loop until correct input
            while(((!response.equals("Y")) && (!response.equals("y"))) && ((!response.equals("N")) && (!response.equals("n")))) {
                //get Y or N to play again
                System.out.println("Would you like to play again? Y/N");
                response = input.nextLine();
                if ((response.equals("Y")) || (response.equals("y"))) {
                    //create new GameBoard, delete old one
                    return true;
                }
                if ((response.equals("N")) || (response.equals("n"))) {
                    System.exit(0);
                }
            }
        }

        return false;
    }
    /**
    *@pre a cpsc2150.extendedTicTacToe.GameBoard object with a board array is created to print.
    *@post the cpsc2150.extendedTicTacToe.GameBoard object's array is printed to the user as a board.
    */
    private static void printBoard(IGameBoard board) {
        System.out.println(board.toString());
    }

    /**
     *@pre Be ready to provide user input.
     * Remember: 3 <= MAX_row <= 100, 3 <= MAX_col <= 100, 3 <= MAX_marks <= 100
     * MIN_row = 3, MIN_col = 3, MIN_marks = 3
     *@post The MAX_row, MAX_col, and MAX_marks will be set
     *@return The MAX_row, MAX_col, and MAX_marks will be returned in a arroy, array.size() = 3
     */
    private static int[] chooseBoardSizeAndMarkerNum() {

        int MAX_row = 0;
        int MAX_col = 0;
        int MAX_marks = 0;
        int MIN_row = 3;
        int MIN_col = 3;
        int MIN_marks = 3;

        int[] size = new int[3];

        Scanner input = new Scanner(System.in);
        do {
            do {
                System.out.println("How many rows?");
                if (input.hasNextInt())
                    MAX_row = input.nextInt();
                if (MAX_row < MIN_row || MAX_row >= 100)
                    System.out.println("Rows must be between 3 and 100");
            } while (MAX_row < MIN_row || MAX_row >= 100);

            do {
                System.out.println("How many columns?");
                if (input.hasNextInt())
                    MAX_col = input.nextInt();
                if (MAX_col < MIN_col || MAX_col >= 100)
                    System.out.println("Columns must be between 3 and 100");
            } while (MAX_col < MIN_col || MAX_col >= 100);

            do {
                System.out.println("How many in a row to win?");
                if (input.hasNextInt())
                    MAX_marks = input.nextInt();
                if (MAX_marks < MIN_marks || MAX_marks > 25)
                    System.out.println("Must be between 3 and 25 in a row to win");
            } while (MAX_marks < MIN_marks || MAX_marks > 25);

            if(MAX_marks > MAX_row || MAX_marks > MAX_col)
                System.out.println("The number in a row must be less than or equal to the row and column");
        }while(MAX_marks > MAX_row || MAX_marks > MAX_col);

        size[0] = MAX_row;
        size[1] = MAX_col;
        size[2] = MAX_marks;

        return size;
    }

    /**
     *@pre Be ready to provide user input.
     * Remember: 2 <= number of players <= 10
     *@post the number of players is set
     *@return number of players
     */
    private static int setDepth() {
        int depth = 0;
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("How many players?");
            if (input.hasNextInt()) {
                depth = input.nextInt();
                //nextLine catches \n
                input.nextLine();
            }
            if(depth > 10)
                System.out.println("Must be 10 players fewer");
            if(depth < 2)
                System.out.println("Must be at least 2 players");
        } while(depth > 10 || depth < 2);
        //set number of players in the array
        return depth;
    }

    /**
     *@param The number of players, and a char array[number of players] = new char.
     *@pre Be ready to provide user input, 2 <= depth <= 10, array.size() = depth
     *@post The players will each have a character to represent them.
     *@return An array containing each players character, in order of players.
     */
    private static char[] choosePlayerMarkers(int depth, char[] player) {
        boolean repeatedCharacter = true;
        String character;
        char checkIfCharacterIsTaken; //for comparing if a character is already being used by another player
        Scanner input = new Scanner(System.in);
        for(int i = 0; i < depth; i++) {
            //do while loop to repeat if character is taken
            do {
                System.out.println("Enter the character to represent player " + (i + 1));
                character = input.nextLine();
                player[i] = character.charAt(0);
                if (player[i] >= 97 && player[i] <= 122)
                    player[i] = (char) (player[i] - 32);
                //can assume they will always enter just a character so no check(from prompt)
                checkIfCharacterIsTaken = player[i];
                //set boolean to false, if repeatedCharacter = true, then there are 2 of the same character and loop
                //if repeatedCharacter = false, then the loop ends
                //set repeatedCharacter to false before the loop and it will be changed to true in the following for loop
                repeatedCharacter = false;
                for (int j = 0; j < depth; j++) {
                    if (checkIfCharacterIsTaken == player[j] && i!=j) {
                        repeatedCharacter = true;
                        System.out.println(checkIfCharacterIsTaken + " is already taken as a player token!");
                    }
                }
            } while(repeatedCharacter);
        }
        return player;
    }
}
