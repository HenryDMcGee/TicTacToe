package cpsc2150.extendedTicTacToe;

/**
 * holds the gameboard and information regarding its size and maximum number of marks needed to win
 * Defines: Max Rows:maximum number of rows
 *          Max Columns: maximum number of columns
 *          Max Marks: maximum number of markers needed for a win
 *          Gameboard: the gameboard made up of the number of rows and columns
 *
 * Initialization Ensures: a board is created with a certain number of rows, columns, and number of marks in a row to win
 * Constraints 3<=Max Rows<=99
 *             3<=Max Columns<=99
 *             3<=Max Marks<=25
 */
public interface IGameBoard {
    /**
     *@return true if game is won
     *@param BoardPosition obj, records a row and column for what location the player selected.
     *@pre cpsc2150.extendedTicTacToe.BoardPosition obj with valid row and column. (checkSpace double checks)
     *@post Figures out if a win or draw occured. Afterwards, ends program if player decides they do not want to play again.
     */

    default boolean checkForWinner(BoardPosition lastPos) {
        char player = whatsAtPos(lastPos);

        if(checkHorizontalWin(lastPos, player))
            return true;
        else if(checkVerticalWin(lastPos, player))
            return true;
        else if(checkDiagonalWin(lastPos, player))
            return true;

        return false;
    }

    /**
     *@return bool: true = draw occured, false = no draw occured.
     *@pre board is setup using an array with a matching row and column size.
     *@post If a draw(where all the squares on the board are filled) occurs it is true.
     */
    default boolean checkForDraw() {
        int i = 0;
        int j = 0;

        for(i = 0; i <= getNumRows(); i++) {
            for(j = 0; j <= getNumColumns(); j++) {
                BoardPosition location = new BoardPosition(i,j);
                if(whatsAtPos(location) == ' ')
                    return false;
            }
        }

        return true;
    }

    /**
     *@return true if game is won
     *@param takes in a cpsc2150.extendedTicTacToe.BoardPosition object that contains the row and column of last choice.
     *@param takes in a a char of which players turn it is.
     *@pre the cpsc2150.extendedTicTacToe.BoardPosition object contains a valid row and column within the grid and not already taken.
     *@post determines whether horizontally there are MAX_marks in a row, thus returns true for a win.
     */
    default boolean checkHorizontalWin(BoardPosition lastPos, char player) {
        int row = lastPos.getRow();
        int col = lastPos.getColumn();
        int leftCounter = 0;
        int rightCounter = 0;
        //false when the next board position checked is a player char
        //becomes true during a player char and stops searching in that direction
        boolean stopLeft = false;
        boolean stopRight = false;
        BoardPosition location;

        for(int i = 0; i < getNumToWin(); i++) {
            //should never get negative col
            if(stopLeft == false) {
                if (col - i > -1) {
                    location = new BoardPosition(row, col - i);
                    if (isPlayerAtPos(location,player))
                        leftCounter++;
                    else
                        stopLeft = true;
                }
            }
            if(stopRight == false) {
                //should never go beyond grid size
                if (col + i <= getNumColumns()) {
                    location = new BoardPosition(row, col + i);
                    if (isPlayerAtPos(location,player))
                        rightCounter++;
                    else
                        stopRight = true;
                }
            }
        }

        if(leftCounter >= getNumToWin() || rightCounter >= getNumToWin())
            return true;
        //for if lastPos is in the middle
        if((leftCounter + rightCounter) - 1 >= getNumToWin())
            return true;

        return false;
    }

    /**
     *@return true if game is won (5 vertical in a row).
     *@param BoardPosition object of players last move (row and column).
     *@param char for player that made the last move.
     *@pre the cpsc2150.extendedTicTacToe.BoardPosition object contains a valid row and column within the grid and not already taken.
     *@post determines whether vertically there are 5 in a row, thus returning true for a win.
     */
    default boolean checkVerticalWin(BoardPosition lastPos, char player) {
        int row = lastPos.getRow();
        int col = lastPos.getColumn();
        int upCounter = 0;
        int downCounter = 0;
        boolean stopUp = false;
        boolean stopDown = false;
        BoardPosition location;

        for(int i = 0; i < getNumToWin(); i++) {
            if(stopUp == false) {
                if (row - i > -1) {
                    location = new BoardPosition(row - i, col);
                    if (isPlayerAtPos(location,player))
                        upCounter++;
                    else
                        stopUp = true;
                }
            }

            if(stopDown == false) {
                if (row + i <= getNumRows()) {
                    location = new BoardPosition(row + i, col);
                    if (isPlayerAtPos(location,player))
                        downCounter++;
                    else
                        stopDown = true;
                }
            }
        }

        if(upCounter >= getNumToWin() || downCounter >= getNumToWin())
            return true;
        if((upCounter + downCounter) - 1 >= getNumToWin())
            return true;

        return false;
    }

    /**
     *@return true if game is won (5 diagonally in a row)
     *@param BoardPosition object of players last move (row and column).
     *@param char for player that made the last move.
     *@pre the cpsc2150.extendedTicTacToe.BoardPosition object contains a valid row and column within the grid and not already taken.
     *@post determines whether diagonally there are 5 in a row, thus returning true for a win.
     */
    default boolean checkDiagonalWin(BoardPosition lastPos, char player) {
        int row = lastPos.getRow();
        int col = lastPos.getColumn();

        int upLeftCounter = 0;
        int upRightCounter = 0;
        int downLeftCounter = 0;
        int downRightCounter = 0;

        boolean stopUpLeft = false;
        boolean stopUpRight = false;
        boolean stopDownLeft = false;
        boolean stopDownRight = false;

        BoardPosition location;

        for(int i = 0; i < getNumToWin(); i++) {
            if(stopUpLeft == false) {
                if ((row - i > -1) && (col - i > -1)) {
                    location = new BoardPosition(row - i, col - i);
                    if (isPlayerAtPos(location,player))
                        upLeftCounter++;
                    else
                        stopUpLeft = true;
                }
            }

            if(stopUpRight == false) {
                if ((row - i > -1) && (col + i <= getNumColumns())) {
                    location = new BoardPosition(row - i, col + i);
                    if (isPlayerAtPos(location,player))
                        upRightCounter++;
                    else
                        stopUpRight = true;
                }
            }

            if(stopDownLeft == false) {
                if ((row + i <= getNumRows()) && (col - i > -1)) {
                    location = new BoardPosition(row + i, col - i);
                    if (isPlayerAtPos(location,player))
                        downLeftCounter++;
                    else
                        stopDownLeft = true;
                }
            }

            if(stopDownRight == false) {
                if ((row + i <= getNumRows()) && (col + i <= getNumColumns())) {
                    location = new BoardPosition(row + i, col + i);
                    if (isPlayerAtPos(location,player))
                        downRightCounter++;
                    else
                        stopDownRight = true;
                }
            }
        }

        if(upLeftCounter >= getNumToWin() || upRightCounter >= getNumToWin() || downLeftCounter >= getNumToWin() || downRightCounter >= getNumToWin())
            return true;
        if((upLeftCounter + downRightCounter) - 1 >= getNumToWin() || (upRightCounter + downLeftCounter) - 1 >= getNumToWin())
            return true;

        return false;
    }

    /**
     *@return char of the player name (X or O or ' ') located at the given cpsc2150.extendedTicTacToe.BoardPosition object. (row and column in object)
     *@param BoardPosition object of players last move including row and column.
     *@pre The cpsc2150.extendedTicTacToe.BoardPosition object contains a valid row and column within the grid and not already taken.
     *@post returns the char for given row and column, so ' ', 'X', or 'O'.
     */
    char whatsAtPos(BoardPosition lastPos);

    /**
     *@return true if the space is available, meaning within bounds 1-8 by 1-8 and not already taken.
     *@param BoardPosition object to check.
     *@pre cpsc2150.extendedTicTacToe.BoardPosition object contains a row and column to check.
     *@post returns true when the given cpsc2150.extendedTicTacToe.BoardPosition object is within boundaries and not already in use.
     */
    default boolean checkSpace(BoardPosition lastPos) {
        int row = lastPos.getRow();
        int col = lastPos.getColumn();

        if (row > -1 && row <= getNumRows()) {
            if (col > -1 && col <= getNumColumns()) {
                if (whatsAtPos(lastPos) == ' ')
                    return true;
            }
        }

        return false;
    }

    /**
     *@param BoardPosition object of row and column to place.
     *@param char player to place (X or O) at given location.
     *@pre the cpsc2150.extendedTicTacToe.BoardPosition object is within bounds and not already taken.
     *Player name is valid X or O.
     *@post a marker of the players name is located at the given position.
     */
    void placeMarker(BoardPosition marker, char player);


    /**
     *@return returns true if a player is located at the given row and column.
     *@param BoardPosition contains row and column of position to check.
     *@param char of player name to check if is at given row and column.
     *@pre The player cannot be a ' '
     * The cpsc2150.extendedTicTacToe.BoardPosition object contains a valid position within the grid and not already taken.
     *Also the player name is either X or O.
     *@post returns true when the given player char is located at the given position.
     */
    default boolean isPlayerAtPos(BoardPosition lastPos, char player) {
        if(whatsAtPos(lastPos) == player)
            return true;

        return false;
    }
    /**
     * @pre ready to receive an integer value and casted if needed
     * @post an integer value will be returned
     * @return the integer Max number of rows
     */
    int getNumRows();

    /**
     * @pre ready to receive an integer value and casted if needed
     * @post an integer value will be returned
     * @return the integer Max number of columns
     */
    int getNumColumns();

    /**
     * @pre ready to receive an integer value and casted if needed
     * @post an integer value will be returned
     * @return the integer Max number of markers in a row
     */
    int getNumToWin();
}
