package cpsc2150.extendedTicTacToe;

public abstract class AbsGameBoard implements IGameBoard {
    /**
     *@pre a cpsc2150.extendedTicTacToe.GameBoard object with a board array is created to print.
     *@post the cpsc2150.extendedTicTacToe.GameBoard object's array is printed to the user as a board.
     */
    @Override
    public String toString() {
        int i = 0;
        int j = 0;
        String output = "";

        output = output + "    ";
        //for numbers on top
        for(i = 0; i <= getNumColumns(); i++) {
            //if else for double digit spacing and single digit spacing
            //for single digits

                //for two digits

            if (i > 8) {
                output = output + Integer.toString(i);
                output = output + "|";
            }
            else {
                output = output + Integer.toString(i);
                output = output + "| ";
            }

        }

        output = output + "\n";
        i = 0;
        for(i = 0; i <= getNumRows(); i++) {
            //for numbers on left side
            if(i > 9) {
                output = output + Integer.toString(i);
                output = output + "|";
            }
            else {
                output = output + " ";
                output = output + Integer.toString(i);
                output = output + "|";
            }
            //for columns
            for(j = 0; j <= getNumColumns(); j++) {
                BoardPosition location = new BoardPosition(i,j);
                //Extra space if not a double digit

                output = output + whatsAtPos(location);
                output = output + ' ';


                //if a blank space make a little longer to fit the same space as an int
                output = output + "|";
                //for new line after each row
                if(j == getNumColumns())
                    output = output + "\n";
            }
        }

        return output;
    }
}
