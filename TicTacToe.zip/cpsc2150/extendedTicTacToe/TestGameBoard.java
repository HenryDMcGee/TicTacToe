package cpsc2150.extendedTicTacToe;

import org.junit.Test;
import  static org.junit.Assert.*;

public class TestGameBoard {

    private IGameBoard IFactory(int MAX_row, int MAX_col, int MAX_marks) {
        IGameBoard temporary = new GameBoard(MAX_row, MAX_col, MAX_marks);

        return temporary;
    }

    private char[][] makeArray(int row, int col) {
        char[][] board = new char[row][col];
        int i = 0;
        int j = 0;
        for(i = 0; i < row; i++) {
            for(j = 0; j < col; j++) {
                board[i][j] = ' ';
            }
        }

        return board;
    }
    private String printArray(char[][] board) {
        int i = 0;
        int j = 0;
        String output = "";

        int getNumColumns = board[0].length - 1;
        int getNumRows = board.length - 1;

        output = output + "    ";
        //for numbers on top
        for(i = 0; i <= getNumColumns; i++) {
            //if else for double digit spacing and single digit spacing
            //for single digits

            //for two digits

            if (i > 8) {
                output = output + Integer.toString(i);
                output = output + "|";
            }
            else {
                output = output + Integer.toString(i);
                output = output + "| ";
            }

        }

        output = output + "\n";
        i = 0;
        for(i = 0; i <= getNumRows; i++) {
            //for numbers on left side
            if(i > 9) {
                output = output + Integer.toString(i);
                output = output + "|";
            }
            else {
                output = output + " ";
                output = output + Integer.toString(i);
                output = output + "|";
            }
            //for columns
            for(j = 0; j <= getNumColumns; j++) {
                //Extra space if not a double digit

                output = output + board[i][j];
                output = output + ' ';


                //if a blank space make a little longer to fit the same space as an int
                output = output + "|";
                //for new line after each row
                if(j == getNumColumns)
                    output = output + "\n";
            }
        }

        return output;
    }
//1
    @Test
    public void test_Constructor__MAXrow3_MAXcol3_MAXmarks3() { // 3 MAX_row, 3 MAX_col, 3 MAX_marks  tests lower bounds
        IGameBoard test = IFactory(3,3,3); // inside main takes user input of row - 1 and column - 1 to give array notation (0-2)

        int expectedMAX_row = 3;
        int expectedMAX_col = 3;
        int expectedMAX_marks = 3;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        assertTrue(printArray(board).equals(test.toString()) && test.getNumToWin() == expectedMAX_marks);
    }
//2
    @Test
    public void test_Constructor__MAXrow100_MAXcol100_MAXmarks25() { //test upper bounds
        IGameBoard test = IFactory(100, 100,25);

        int expectedMAX_row = 100;
        int expectedMAX_col = 100;
        int expectedMAX_marks = 25;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        assertTrue(printArray(board).equals(test.toString()) && test.getNumToWin() == expectedMAX_marks);
    }

    //3
    @Test
    public void test_Constructor__MAXrow5_MAXcol5_MAXmarks5() { //testing mid range
        IGameBoard test = IFactory(5,5,5);

        int expectedMAX_row = 5;
        int expectedMAX_col = 5;
        int expectedMAX_marks = 5;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        assertTrue(printArray(board).equals(test.toString()) && test.getNumToWin() == expectedMAX_marks);
    }
//1
    @Test
    public void test_CheckSpace__MAXrow3_MAXcol3_MAXmarks3_row0_col0_True() { //row and column of position to check + if its free then return true, false for taken, check lowerbound of board size empty
        IGameBoard test = IFactory(3,3,3);
        BoardPosition lastPos = new BoardPosition(0,0);

        boolean expectedOutcome = true;

        assertTrue(test.checkSpace(lastPos) == expectedOutcome);
    }
//2
    @Test
    public void test_CheckSpace__MAXrow3_MAXcol3_MAXmarks3_row3_col3_False() { //check upperbound of board size full
        IGameBoard test = IFactory(3, 3, 3);
        BoardPosition lastPos = new BoardPosition(3, 3);
        test.placeMarker(lastPos,'x'); //relying on placeMarker working

        boolean expectedOutcome = false;

        assertTrue(test.checkSpace(lastPos) == false);
    }
//3
    @Test
    public void test_CheckSpace__MAXrow100_MAXcol100_MAXmarks100_row100_col100_false() { //check upperbound of max size, full
        IGameBoard test = IFactory(100, 100, 100);
        BoardPosition lastPos = new BoardPosition(50, 50);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos,'x'); //relying on placeMarker working

        boolean expectedOutcome = false;

        assertTrue(test.checkSpace(lastPos) == false);
    }
//1
    @Test
    public void test_CheckHorizontalWin__MAXrow3_MAXcol3_MAXmarks3() { //col = max marks, 3 in a row(last position on the farthest right), minimum marks
        IGameBoard test = IFactory(3, 3, 3);
        BoardPosition lastPos = new BoardPosition(2, 0);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function

        test.placeMarker(lastPos,'a'); //relying on placeMarker working

        lastPos = new BoardPosition(2, 1);
        test.placeMarker(lastPos,'a'); //relying on placeMarker working

        lastPos = new BoardPosition(2, 2);
        test.placeMarker(lastPos,'a'); //relying on placeMarker working

        boolean expectedOutcome = true;
        char expectedPlayer = 'a';
        int expectedMAX_row = 3;
        int expectedMAX_col = 3;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        board[2][0] = 'a';
        board[2][1] = 'a';
        board[2][2] = 'a';

        assertTrue(printArray(board).equals(test.toString()) && test.checkHorizontalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//2
    @Test
    public void test_CheckHorizontalWin__MAXrow100_MAXcol100_MAXmarks25() { //check upperbound, added last position in the middle,25 marks
        IGameBoard test = IFactory(100, 100, 25);
        BoardPosition lastPos;

        int expectedMAX_row = 100;
        int expectedMAX_col = 100;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        for(int i = 74; i < 100; i++) {
            if(i!=85) {
                lastPos = new BoardPosition(99, i);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
                test.placeMarker(lastPos, 'x'); //relying on placeMarker working
                board[99][i] = 'x';
            }
        }
        //using 85 as a middle value for the checkhorizontal
        lastPos = new BoardPosition(99, 85);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[99][85] = 'x';

        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkHorizontalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//3
    @Test
    public void test_CheckHorizontalWin__MAXrow50_MAXcol50_MAXmarks3() { //check middle, last position to check on the left,3 marks
        IGameBoard test = IFactory(50, 50, 3);
        BoardPosition lastPos;

        //using 85 as a middle value for the checkhorizontal
        lastPos = new BoardPosition(49, 49);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        lastPos = new BoardPosition(49, 48);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        lastPos = new BoardPosition(49, 47);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        boolean expectedOutcome = true;
        char expectedPlayer = 'x';
        int expectedMAX_row = 50;
        int expectedMAX_col = 50;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        board[49][49] = 'x';
        board[49][48] = 'x';
        board[49][47] = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkHorizontalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//4
    @Test
    public void test_CheckHorizontalWin__MAXrow30_MAXcol30_MAXmarks10() { //top left of graph, col = 0-10, 10 in a row , 10 marks
        IGameBoard test = IFactory(30, 30, 10);

        int expectedMAX_row = 30;
        int expectedMAX_col = 30;

        BoardPosition lastPos = new BoardPosition(0,1);
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);
        board[0][1] = 'x';


        for(int i = 2; i < 10; i++) {
                lastPos = new BoardPosition(0, i);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
                test.placeMarker(lastPos, 'x'); //relying on placeMarker working
                board[0][i] = 'x';
        }

        lastPos = new BoardPosition(0,0);
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        board[0][0] = 'x';

        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkHorizontalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//1
    @Test
    public void test_CheckVerticalWin__MAXrow3_MAXcol3_MAXmarks3() { //col = max marks, 3 in a row(last position on the farthest down), minimum marks
        IGameBoard test = IFactory(3, 3, 3);
        BoardPosition lastPos = new BoardPosition(0, 2);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function

        int expectedMAX_row = 3;
        int expectedMAX_col = 3;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);
        board[0][2] = 'z';

        test.placeMarker(lastPos,'z'); //relying on placeMarker working

        lastPos = new BoardPosition(1, 2);
        test.placeMarker(lastPos,'z'); //relying on placeMarker working
        board[1][2] = 'z';

        lastPos = new BoardPosition(2, 2);
        test.placeMarker(lastPos,'z'); //relying on placeMarker working
        board[2][2] = 'z';

        boolean expectedOutcome = true;
        char expectedPlayer = 'z';

        assertTrue(printArray(board).equals(test.toString()) && test.checkVerticalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//2
    @Test
    public void test_CheckVerticalWin__MAXrow100_MAXcol100_MAXmarks25() { //check upperbound, added last position in the middle,25 marks
        IGameBoard test = IFactory(100, 100, 25);
        BoardPosition lastPos;

        int expectedMAX_row = 100;
        int expectedMAX_col = 100;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        for(int i = 74; i < 100; i++) {
            if(i!=85) {
                lastPos = new BoardPosition(i, 99);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
                test.placeMarker(lastPos, 'l'); //relying on placeMarker working
                board[i][99] = 'l';
            }
        }
        //using 85 as a middle value for the checkhorizontal
        lastPos = new BoardPosition(85, 99);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'l'); //relying on placeMarker working
        board[85][99] = 'l';

        boolean expectedOutcome = true;
        char expectedPlayer = 'l';

        assertTrue(printArray(board).equals(test.toString()) && test.checkVerticalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//3
    @Test
    public void test_CheckVerticalWin__MAXrow50_MAXcol50_MAXmarks3() { //check middle, last position to check on the left,3 marks
        IGameBoard test = IFactory(50, 50, 3);
        BoardPosition lastPos;

        int expectedMAX_row = 50;
        int expectedMAX_col = 50;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        //using 85 as a middle value for the checkhorizontal
        lastPos = new BoardPosition(49, 49);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'p'); //relying on placeMarker working
        board[49][49] = 'p';

        lastPos = new BoardPosition(48, 49);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'p'); //relying on placeMarker working
        board[48][49] = 'p';

        lastPos = new BoardPosition(47, 49);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'p'); //relying on placeMarker working
        board[47][49] = 'p';

        boolean expectedOutcome = true;
        char expectedPlayer = 'p';

        assertTrue(printArray(board).equals(test.toString()) && test.checkVerticalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//4
    @Test
    public void test_CheckVerticalWin__MAXrow30_MAXcol30_MAXmarks10() { //top left of graph, col = 0-10, 10 in a row , 10 marks
        IGameBoard test = IFactory(30, 30, 10);
        BoardPosition lastPos = new BoardPosition(0,0);
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        int expectedMAX_row = 30;
        int expectedMAX_col = 30;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);
        board[0][0] = 'x';

        for(int i = 1; i < 10; i++) {
            lastPos = new BoardPosition(i, 0);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
            test.placeMarker(lastPos, 'x'); //relying on placeMarker working
            board[i][0] = 'x';
        }

        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkVerticalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//1
    @Test
    public void test_CheckDiagonalWin__MAXrow30_MAXcol30_MAXmarks10() { //top left of graph, going down and right, col = 0-10, 10 in a row , 10 marks
        IGameBoard test = IFactory(30, 30, 10);
        BoardPosition lastPos = new BoardPosition(0,0);
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        int expectedMAX_row = 30;
        int expectedMAX_col = 30;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);
        board[0][0] = 'x';

        for(int i = 1; i < 10; i++) {
            lastPos = new BoardPosition(i, i);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
            test.placeMarker(lastPos, 'x'); //relying on placeMarker working
            board[i][i] = 'x';
        }

        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkDiagonalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//2
    @Test
    public void test_CheckDiagonalWin__MAXrow3_MAXcol3_MAXmarks3() { //bottom left of table to top right col = 0-3, 3 in a row, 3 marks
        IGameBoard test = IFactory(3, 3, 3);
        BoardPosition lastPos = new BoardPosition(2,0);
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        int expectedMAX_row = 3;
        int expectedMAX_col = 3;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);
        board[2][0] = 'x';

        for(int i = 0; i < 3; i++) {
            lastPos = new BoardPosition(2-i, i);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
            test.placeMarker(lastPos, 'x'); //relying on placeMarker working
            board[2-i][i] = 'x';
        }

        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkDiagonalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//3
    @Test
    public void test_CheckDiagonalWin__MAXrow50_MAXcol50_MAXmarks20() { //bottom right of table going up and left, Adding last position in the middle (39,39), 20 in a row, 20 marks
        IGameBoard test = IFactory(50, 50, 20);
        BoardPosition lastPos = new BoardPosition(49,49);
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        int expectedMAX_row = 50;
        int expectedMAX_col = 50;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);
        board[49][49] = 'x';

        for(int i = 1; i < 20; i++) {
            if(i!=10) {
                lastPos = new BoardPosition(49 - i, 49 - i);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
                test.placeMarker(lastPos, 'x'); //relying on placeMarker working
                board[49 - i][49 - i] = 'x';
            }
        }

        lastPos = new BoardPosition(39, 39);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[39][39] = 'x';


        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkDiagonalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//4
    @Test
    public void test_CheckDiagonalWin__MAXrow5_MAXcol5_MAXmarks3() { //Top right of table going down and left, 3 in a row, max marks  = 3
        IGameBoard test = IFactory(5, 5, 3);
        BoardPosition lastPos = new BoardPosition(4,4);
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working

        int expectedMAX_row = 5;
        int expectedMAX_col = 5;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);
        board[4][4] = 'x';

        for(int i = 0; i < 3; i++) {
                lastPos = new BoardPosition(i, 2 - i);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
                test.placeMarker(lastPos, 'x'); //relying on placeMarker working
                board[i][2 - i] = 'x';
        }


        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkDiagonalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//5
    @Test
    public void test_CheckDiagonalWin__MAXrow6_MAXcol6_MAXmarks3() { //bottom middle of the table, going up and right, 3 in a row, max marks  = 3
        IGameBoard test = IFactory(6, 6, 3);


        int expectedMAX_row = 6;
        int expectedMAX_col = 6;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition lastPos = new BoardPosition(5, 2);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[5][2] = 'x';

        lastPos = new BoardPosition(4, 3);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[4][3] = 'x';

        lastPos = new BoardPosition(3, 4);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[3][4] = 'x';

        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkDiagonalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//6
    @Test
    public void test_CheckDiagonalWin__MAXrow15_MAXcol15_MAXmarks5() { //top middle of the table, down and right, 5 in a row, max marks  = 5
        IGameBoard test = IFactory(15, 15, 5);


        int expectedMAX_row = 15;
        int expectedMAX_col = 15;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition lastPos = new BoardPosition(0, 7);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[0][7] = 'x';

        lastPos = new BoardPosition(1, 8);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[1][8] = 'x';

        lastPos = new BoardPosition(2, 9);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[2][9] = 'x';

        lastPos = new BoardPosition(3, 10);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[3][10] = 'x';

        lastPos = new BoardPosition(4, 11);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[4][11] = 'x';
        boolean expectedOutcome = true;
        char expectedPlayer = 'x';

        assertTrue(printArray(board).equals(test.toString()) && test.checkDiagonalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//7
    @Test
    public void test_CheckDiagonalWin__MAXrow50_MAXcol50_MAXmarks25() { //middle of the left of the table, up and right, 25 in a row, max marks  = 25
        IGameBoard test = IFactory(50, 50, 25);


        int expectedMAX_row = 50;
        int expectedMAX_col = 50;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition lastPos = new BoardPosition(25, 0);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'x'); //relying on placeMarker working
        board[25][0] = 'x';


        for(int i = 25; i < 48; i++) {
            lastPos = new BoardPosition(49-i, i-24);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
            test.placeMarker(lastPos, 'x'); //relying on placeMarker working
            board[49-i][i-24] = 'x';
        }
        boolean expectedOutcome = false;
        char expectedPlayer = 'x';

        lastPos = new BoardPosition(1, 24);  //The place marker function access the array 0 based, so array is 0-99, thus the BoardPosition row -1 and col -1 must be used. Thus is done in the main before using the function
        test.placeMarker(lastPos, 'p'); //relying on placeMarker working
        board[1][24] = 'p';

        assertTrue(printArray(board).equals(test.toString()) && test.checkDiagonalWin(lastPos, expectedPlayer) == expectedOutcome);
    }
//1
    @Test
    public void test_CheckForDraw__MAXrow25_MAXcol25_MAXmarks25() { //fill the board from top left to bottom right and check if it is a draw(it should be)
        IGameBoard test = IFactory(25, 25, 25);


        int expectedMAX_row = 25;
        int expectedMAX_col = 25;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        //check for draw does not check if there is a win, so I can fill the board with only 1 symbol and it should be fine
        for(int i = 0; i < 25; i++) {
            for(int j = 0; j < 25; j++) {
                BoardPosition location = new BoardPosition(i,j);
                test.placeMarker(location, 'a');
                board[i][j] = 'a';
            }
        }

        boolean expectedOutcome = true;

        assertTrue(printArray(board).equals(test.toString()) && test.checkForDraw() == expectedOutcome);
    }
//2
    @Test
    public void test_CheckForDraw__MAXrow100_MAXcol100_MAXmarks25() { //fill the board from top left to bottom right, all but ONE slot of the board is filled(should not be a draw)
        IGameBoard test = IFactory(100, 100, 25);


     int expectedMAX_row = 100;
        int expectedMAX_col = 100;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

      //check for draw does not check if there is a win, so I can fill the board with only 1 symbol and it should be fine
        for(int i = 0; i < 100; i++) {
            for(int j = 0; j < 100; j++) {
                if(i != 99 || j != 99) {
                    BoardPosition location = new BoardPosition(i, j);
                    test.placeMarker(location, 'a');
                    board[i][j] = 'a';
                }
            }
        }

        boolean expectedOutcome = false;

        assertTrue(printArray(board).equals(test.toString()) && test.checkForDraw() == expectedOutcome);
    }
//3
    @Test
    public void test_CheckForDraw__MAXrow10_MAXcol10_MAXmarks5() { //fill the board and place last marker at 0,0, x for 0,0
        IGameBoard test = IFactory(10, 10, 5);


        int expectedMAX_row = 10;
        int expectedMAX_col = 10;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        //check for draw does not check if there is a win, so I can fill the board with only 1 symbol and it should be fine
        for(int i = 0; i < 10; i++) {
            for(int j = 0; j < 10; j++) {
                if(i != 0 || j != 0) {
                    BoardPosition location = new BoardPosition(i, j);
                    test.placeMarker(location, 'q');
                    board[i][j] = 'q';
                }
            }
        }

        BoardPosition location = new BoardPosition(0, 0);
        test.placeMarker(location, 'x');
        board[0][0] = 'x';

        boolean expectedOutcome = true;

        assertTrue(printArray(board).equals(test.toString()) && test.checkForDraw() == expectedOutcome);
    }
//4
    @Test
    public void test_CheckForDraw__MAXrow10_MAXcol10_MAXmarks4() { //fill the board and place last marker at 5,5
        IGameBoard test = IFactory(10, 10, 4);


        int expectedMAX_row = 10;
        int expectedMAX_col = 10;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        //check for draw does not check if there is a win, so I can fill the board with only 1 symbol and it should be fine
        for(int i = 0; i < 10; i++) {
            for(int j = 0; j < 10; j++) {
                if(i != 4 || j != 4) {
                    BoardPosition location = new BoardPosition(i, j);
                    test.placeMarker(location, 'q');
                    board[i][j] = 'q';
                }
            }
        }

        BoardPosition location = new BoardPosition(4, 4);
        test.placeMarker(location, 'x');
        board[4][4] = 'x';

        boolean expectedOutcome = true;

        assertTrue(printArray(board).equals(test.toString()) && test.checkForDraw() == expectedOutcome);
    }
//1
    @Test
    public void test_WhatsAtPos__MAXrow3_MAXcol3() { //checking 0,0 lower boundary
        IGameBoard test = IFactory(3, 3, 3);


        int expectedMAX_row = 3;
        int expectedMAX_col = 3;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(2, 2);
        test.placeMarker(location, 'a');
        board[2][2] = 'a';

        location = new BoardPosition(1, 1);
        test.placeMarker(location, 'b');
        board[1][1] = 'b';

        location = new BoardPosition(0, 0);
        test.placeMarker(location, 'c');
        board[0][0] = 'c';

        char expected = 'c';

        assertTrue(printArray(board).equals(test.toString()) && test.whatsAtPos(location) == expected);
    }
//2
    @Test
    public void test_WhatsAtPos__MAXrow10_MAXcol10() { //checking 10,10 upper boundary
        IGameBoard test = IFactory(10, 10, 3);


        int expectedMAX_row = 10;
        int expectedMAX_col = 10;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);BoardPosition location = new BoardPosition(0, 0);

        for(int i = 0; i < 9; i++) {
            for(int j = 0; j < 9; j++) {
                if(i != 4 || j != 4) {
                    location = new BoardPosition(i, j);
                    test.placeMarker(location, 'q');
                    board[i][j] = 'q';
                }
            }
        }
        location = new BoardPosition(4, 4);
        test.placeMarker(location, 'a');
        board[4][4] = 'a';

        char expected = 'a';

        assertTrue(printArray(board).equals(test.toString()) && test.whatsAtPos(location) == expected);
    }
//3
    @Test
    public void test_WhatsAtPos__MAXrow4_MAXcol4_num() { //checking if number symbols work
        IGameBoard test = IFactory(4, 4, 3);


        int expectedMAX_row = 4;
        int expectedMAX_col = 4;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(2, 0);
        test.placeMarker(location, '3');
        board[2][0] = '3';
        char expected = '3';

        assertTrue(printArray(board).equals(test.toString()) && test.whatsAtPos(location) == expected);
    }
//4
    @Test
    public void test_WhatsAtPos__MAXrow5_MAXcol5() { //checking if the space is in the top right
        IGameBoard test = IFactory(5, 5, 3);


        int expectedMAX_row = 5;
        int expectedMAX_col = 5;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(0, 4);
        test.placeMarker(location, 'd');
        board[0][4] = 'd';

        char expected = 'd';

        assertTrue(printArray(board).equals(test.toString()) && test.whatsAtPos(location) == expected);
    }
//5
    @Test
    public void test_WhatsAtPos__MAXrow4_MAXcol4() { //q o d, checking o when the symbols next to it are different
        IGameBoard test = IFactory(4, 4, 4);


        int expectedMAX_row = 4;
        int expectedMAX_col = 4;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(0, 3);
        test.placeMarker(location, 'd');
        board[0][3] = 'd';

        location = new BoardPosition(0, 1);
        test.placeMarker(location, 'q');
        board[0][1] = 'q';

        location = new BoardPosition(0, 2);
        test.placeMarker(location, 'o');
        board[0][2] = 'o';

        assertTrue(printArray(board).equals(test.toString()) && test.whatsAtPos(location) == 'o');
    }
//1
    @Test
    public void test_isPlayerAtPos__MAXrow4_MAXcol4() { //if player is at upperbound 4,4
        IGameBoard test = IFactory(4, 4, 4);


        int expectedMAX_row = 4;
        int expectedMAX_col = 4;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(3, 3);
        test.placeMarker(location, 'd');
        board[3][3] = 'd';

        boolean expectedOutcome = true;
        char expectedChar = 'd';

        assertTrue(printArray(board).equals(test.toString()) && test.isPlayerAtPos(location, expectedChar) == expectedOutcome);
    }
//2
    @Test
    public void test_isPlayerAtPos__MAXrow5_MAXcol5_MAXmarks5() { //if player is at upperbound 0,0
        IGameBoard test = IFactory(5, 5, 5);


        int expectedMAX_row = 5;
        int expectedMAX_col = 5;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(0, 0);
        test.placeMarker(location, 'd');
        board[0][0] = 'd';

        boolean expectedOutcome = true;
        char expectedChar = 'd';

        assertTrue(printArray(board).equals(test.toString()) && test.isPlayerAtPos(location, expectedChar) == expectedOutcome);
    }
//3
    @Test
    public void test_isPlayerAtPos__MAXrow6_MAXcol6() { //if player is not at position, 4,4, d ' ' d
        IGameBoard test = IFactory(6, 6, 6);


        int expectedMAX_row = 6;
        int expectedMAX_col = 6;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(4, 3);
        test.placeMarker(location, 'd');
        board[4][3] = 'd';

        location = new BoardPosition(4, 5);
        test.placeMarker(location, 'd');
        board[4][5] = 'd';

        boolean expectedOutcome = false;
        char expectedChar = 'd';

        location = new BoardPosition(4, 4);

        assertTrue(printArray(board).equals(test.toString()) && test.isPlayerAtPos(location, expectedChar) == expectedOutcome);
    }

//4
    @Test
    public void test_isPlayerAtPos__MAXrow7_MAXcol7() { //if player is not at position, 4,4, d ' ' d
        IGameBoard test = IFactory(7, 7, 6);


        int expectedMAX_row = 7;
        int expectedMAX_col = 7;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(4, 5);
        test.placeMarker(location, 'b');
        board[4][5] = 'b';

        location = new BoardPosition(1, 2);
        test.placeMarker(location, 'a');
        board[1][2] = 'a';

        boolean expectedOutcome = false;
        char expectedChar = 'b';

        assertTrue(printArray(board).equals(test.toString()) && test.isPlayerAtPos(location, expectedChar) == expectedOutcome);
    }

    //5
    @Test
    public void test_isPlayerAtPos__MAXrow3_MAXcol3() { //if player is not at position, 4,4, d ' ' d
        IGameBoard test = IFactory(3, 3, 3);


        int expectedMAX_row = 3;
        int expectedMAX_col = 3;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(1, 1);
        test.placeMarker(location, '3');
        board[1][1] = '3';


        boolean expectedOutcome = true;
        char expectedChar = '3';

        assertTrue(printArray(board).equals(test.toString()) && test.isPlayerAtPos(location, expectedChar) == expectedOutcome);
    }

    //1
    @Test
    public void test_placeMarker__MAXrow3_MAXcol3() {
        IGameBoard test = IFactory(3, 3, 3);


        int expectedMAX_row = 3;
        int expectedMAX_col = 3;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(1, 1);

        char charToPlace = 'd';

        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                if(i!=2 || j!=2) {
                    location = new BoardPosition(i, j);
                    test.placeMarker(location, 'd');
                    board[i][j] = 'd';
                }
            }
        }

        location = new BoardPosition(2, 2);
        board[2][2] = charToPlace;
        test.placeMarker(location, charToPlace);

        assertTrue(printArray(board).equals(test.toString()));
    }
//2
    @Test
    public void test_placeMarker__MAXrow5_MAXcol5() { //if player is not at position, 4,4, d ' ' d
        IGameBoard test = IFactory(5, 5, 5);


        int expectedMAX_row = 5;
        int expectedMAX_col = 5;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        BoardPosition location = new BoardPosition(0, 1);
        test.placeMarker(location, 'a');
        board[0][1] = 'a';

        location = new BoardPosition(0, 2);
        test.placeMarker(location, 'a');
        board[0][2] = 'a';

        location = new BoardPosition(0, 3);
        test.placeMarker(location, 'a');
        board[0][3] = 'a';

        location = new BoardPosition(1, 1);
        test.placeMarker(location, 'a');
        board[1][1] = 'a';

        location = new BoardPosition(2, 1);
        test.placeMarker(location, 'a');
        board[2][1] = 'a';

        location = new BoardPosition(2, 2);
        test.placeMarker(location, 'a');
        board[2][2] = 'a';

        location = new BoardPosition(2, 3);
        test.placeMarker(location, 'a');
        board[2][3] = 'a';

        location = new BoardPosition(1, 3);
        test.placeMarker(location, 'a');
        board[1][3] = 'a';

        char charToPlace = 'z';
        int expectedRow = 1;
        int expectedColumn = 2;

        location = new BoardPosition(expectedRow, expectedColumn);

        test.placeMarker(location, charToPlace);
        board[expectedRow][expectedColumn] = 'z';

        assertTrue(printArray(board).equals(test.toString()));
    }
//3
    @Test
    public void test_placeMarker__MAXrow6_MAXcol5() { //if player is not at position, 4,4, d ' ' d
        IGameBoard test = IFactory(6, 5, 5);


        int expectedMAX_row = 6;
        int expectedMAX_col = 5;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        char charToPlace = 'w';
        int expectedRow = 5;
        int expectedColumn = 4;

        BoardPosition location = new BoardPosition(expectedRow, expectedColumn);

        test.placeMarker(location, charToPlace);
        board[expectedRow][expectedColumn] = 'w';

        assertTrue(printArray(board).equals(test.toString()));
    }
//4
    @Test
    public void test_placeMarker__MAXrow5_MAXcol6() { //if player is not at position, 4,4, d ' ' d
        IGameBoard test = IFactory(5, 6, 5);


        int expectedMAX_row = 5;
        int expectedMAX_col = 6;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        char charToPlace = 'w';
        int expectedRow = 0;
        int expectedColumn = 0;

        BoardPosition location = new BoardPosition(expectedRow, expectedColumn);

        test.placeMarker(location, charToPlace);
        board[expectedRow][expectedColumn] = 'w';

        assertTrue(printArray(board).equals(test.toString()));
    }
//5
    @Test
    public void test_placeMarker__MAXrow7_MAXcol6() {
        IGameBoard test = IFactory(7, 6, 5);


        int expectedMAX_row = 7;
        int expectedMAX_col = 6;

        char[][] board = makeArray(expectedMAX_row, expectedMAX_col);

        char charToPlace = 'p';
        int expectedRow = 2;
        int expectedColumn = 1;

        BoardPosition location = new BoardPosition(expectedRow, expectedColumn);

        test.placeMarker(location, charToPlace);
        board[expectedRow][expectedColumn] = 'p';

        assertTrue(printArray(board).equals(test.toString()));
    }
}
